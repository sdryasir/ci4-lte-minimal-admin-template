<?php namespace App\Controllers;

class Home extends BaseController
{
	public function index()
	{
		 $data = [
            'page_title' => 'Dashboard'
        ];
		echo view('incl/header', $data);
		echo view('page');
		echo view('incl/footer');
	}
}
